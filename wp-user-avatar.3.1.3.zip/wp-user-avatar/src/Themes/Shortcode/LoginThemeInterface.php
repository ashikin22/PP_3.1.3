<?php

namespace ProfilePress\Core\Themes\Shortcode;


interface LoginThemeInterface extends ThemeInterface
{

}
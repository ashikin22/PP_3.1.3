<?php

namespace ProfilePress\Core\Themes\Shortcode;


interface RegistrationThemeInterface extends ThemeInterface
{
    public function success_message();
}